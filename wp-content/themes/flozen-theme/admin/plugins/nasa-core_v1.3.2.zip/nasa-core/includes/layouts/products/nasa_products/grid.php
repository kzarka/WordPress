<?php
include NASA_CORE_PRODUCT_LAYOUTS . 'globals/row_layout.php';
